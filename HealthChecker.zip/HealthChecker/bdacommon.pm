#!/usr/bin/perl
#
# $Header: bda/src/tools/bdacommon.pm /main/46 2018/03/30 11:53:42 jiajzhan Exp $
#
# bdacommon.pm
#
# Copyright (c) 2011, 2018, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      bdacommon.pm - common bda routines
#
#    DESCRIPTION
#      Common routines for BDA perl scripts
#
#    NOTES
#
#    MODIFIED   (MM/DD/YY)
#    lobolano    02/07/18 - adding scapepwdforbash function
#    manumuno    10/31/17 - Adding an if to not overwrite the status with
#                           WARNING when it already has a FAILURE
#    alangarc    11/14/16 - adding existsinSet and isBase64 subroutines
#    raragarc    10/17/16 - Max Value Check
#    raragarc    07/11/16 - Enhanced Network Files
#    luisr       06/29/16 - Add checkMinAlphanumValue to check Alpha-numeric
#                           firmware versions.
#    rafaegar    01/19/16 - let certain objects to be loaded from config.json
#    rahularo    11/17/15 - Using JSON.pm instead of json-select for subroutine
#                           isValidJson()
#    rahularo    07/20/15 - Added getVirtualBlockDevID()
#    rahularo    06/18/15 - Added isValidJson(), execCmdWithTimeout() and clearAllXenstoreMsgFields()
#    rahularo    06/14/15 - Adding common xenstore subroutines
#    rahularo    05/26/15 - Adding getHostEnvironment
#    rramkiss    05/13/15 - nicer message during mammoth run
#    ashehadi    11/11/14 - Deleting non-printable chars
#    ashehadi    11/11/14 - Fixing bdacli call
#    ashehadi    11/10/14 - Fixing typo
#    ashehadi    11/10/14 - Changing bdacli param to the correct one
#    ashehadi    11/10/14 - Using bdacli getinfo instead directly using
#                           json-select
#    rramkiss    08/07/14 - use config.json by default
#    rramkiss    04/16/14 - IncludeConfig should return 0/1 for perl true/false
#    rgmani      02/27/14 - Changes needed to work with JSON config
#    rramkiss    10/03/12 - fix CheckValueList for special chars
#    rramkiss    05/17/12 - add utility function checkValueList
#    rramkiss    03/08/12 - tweak firmware min version output
#    rramkiss    02/28/12 - add includeConfig
#    rramkiss    02/17/12 - update logging to support multiple files
#    rramkiss    01/06/12 - tweak checkMinValue output
#    rramkiss    12/14/11 - print firmware levels in hex
#    rramkiss    12/12/11 - add checkMinValue
#    ssingla     08/08/11 - rename to oak
#    ssingla     05/24/11 - creation
#    ssingla     05/24/11 - Creation

#provide functions for message reporting and tracing for oak validate tool.

package bdacommon;

use strict;
use warnings;
use threads;

use Exporter;

use Term::ANSIColor qw(:constants);
use Data::Dumper;
use MIME::Base64;
use MIME::QuotedPrint qw(encode_qp);
use Encode qw(encode);
use Socket;


# This forces JSON.pm to always use the PP (Pure Perl impl.)
# backend (instead of searching first for JSON::XS)
BEGIN{
  $ENV{PERL_JSON_BACKEND} = 'JSON::PP';
  $ENV{'PATH'} = '/opt/oracle/bda/bin:' . $ENV{'PATH'};

  my $ADE_PRODUCT_ROOT = $ENV{"ADE_PRODUCT_ROOT"};
  if (defined $ADE_PRODUCT_ROOT && length($ADE_PRODUCT_ROOT) > 0) {
    eval 'use lib "$ADE_PRODUCT_ROOT/cloud/lib"';
  }
  else{
    # Inside BDA machine - Bare, Dom0 or DomU
    eval 'use lib "/opt/oracle/bda/cloud/lib"';
  }
}

# This works for both OL5 and OL6.
use JSON;

#Flag to control the color scheme output. If output redirected to logfile, then it turn it off.
our $colorScheme = 1;

BEGIN {
    our (@ISA) = ('Exporter');
    our (@EXPORT) = (
        'DoExecCmd',
        'FAILURE',
        'SUCCESS',
        'WARNING',
        'checkMaxValue',
        'checkMinAlphanumValue',
        'checkMinValue',
        'checkValue',
        'checkValueList',
        'cleanOutput',
        'decodeAndQuoteBase64',
        'execCmdWithTimeout',
        'existsInSet',
        'getCallStack',
        'getHostEnvironment',
        'getOutputStrFromFile',      
        'getVMNamefromJson', 
        'getFormerVMNamefromJson', 
        'includeConfig',
        'includeJsonConfig',
        'isBase64',
        'isEmpty',
        'isNotEmpty',
        'mapping_domuNames',
        'msgPrint',
        'parallelExecuteCommands',
        'printDataStruct',
        'scapepwdforbash',
        'trim',
        'turnoffColorscheme',
        'turnonColorscheme',
        'updateStatus',
        'writeToLog'
      );
}

use constant {SUCCESS => 0, FAILURE => 1, WARNING => 2};

# Global variables
my $NETWORK_JSON = "/opt/oracle/bda/network.json";
my $RACK_NETWORK_JSON = "/opt/oracle/bda/rack-network.json";


if (-e $RACK_NETWORK_JSON)
{
  $NETWORK_JSON = $RACK_NETWORK_JSON;
}

my $JSON_SELECT = "/opt/oracle/bda/bin/json-select";

sub cleanOutput {
    my ($output) = @_;

    # removes a single \r from the line
    $output =~ s/\r//s;

    # match a single \t OR space right before a \n, and remove
    $output =~ s/[\t ]\n//s;

    # match at least 2 spaces, replace with a single space
    $output =~ s/ +/ /gs;

    # match at least 2 \t, replace with a single space
    $output =~ s/\t+/ /gs;

    # remove a space immediately following a \n
    $output =~ s/\n /\n/s;

    # remove a space immediately following a \t
    $output =~ s/\t /\t/s;

    # match at least 2 \n, replace them all with a single space
    $output =~ s/\n+/ /gs;

    return $output;
}


sub updateStatus {

    if    ($_[0] == FAILURE) {$_[0] = FAILURE;}
    elsif ($_[0] == WARNING) {$_[0] = WARNING;}
    else                     {$_[0] = SUCCESS;}

    if (defined $_[1]) {
        if    ($_[1] == FAILURE) {$_[0] = FAILURE;}
	elsif ($_[1] == WARNING) {
                if($_[0] == SUCCESS){$_[0] = WARNING;}
        }
    }
    return $_[0];
}


sub checkValue {

    my ($outputfile, $valueType, $thisValue, $expectedValue, $status) = @_;

    #Avoid warning of uninitialized value
    if(!defined $status){
      $status = FAILURE;
    }

    $thisValue = defined $thisValue ? $thisValue : "";
    if ($thisValue eq $expectedValue) {
        msgPrint($outputfile, "S", "", "Correct $valueType : $thisValue");
        return SUCCESS;
    }
    elsif ($status == FAILURE) {
        msgPrint($outputfile, "E", "", "Wrong $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Expected $valueType : $expectedValue");
        return FAILURE;
    }
    else {
        msgPrint($outputfile, "W", "", "Wrong $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Expected $valueType : $expectedValue");
        return WARNING;
    }
}

sub checkValueList {
    my ($outputfile, $valueType, $thisValue, $expectedValuesRef, $status) = @_;

    #Avoid warning of uninitialized value
    if(!defined $status){
      $status = FAILURE;
    }

    $thisValue = defined $thisValue ? $thisValue : "";
    my $thisValueEscaped = $thisValue;
    $thisValueEscaped = defined $thisValueEscaped ? $thisValueEscaped : "";
    my @expectedValues   = @$expectedValuesRef;
    $thisValueEscaped =~ s/\(/\\(/;
    $thisValueEscaped =~ s/\)/\\)/;

    if (grep (/^$thisValueEscaped$/, @expectedValues)) {
        msgPrint($outputfile, "S", "", "Correct $valueType : $thisValue");
        return SUCCESS;
    }
    elsif ($status == FAILURE) {
        msgPrint($outputfile, "E", "", "Wrong $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Expected $valueType : " . join(" or ", @expectedValues));
        return FAILURE;
    }
    else {
        msgPrint($outputfile, "W", "", "Wrong $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Expected $valueType : " . join(" or ", @expectedValues));
        return WARNING;
    }
}

sub checkMinValue {
    my $thisValue     = $_[2];
    my $expectedValue = $_[3];
    my $valueType     = $_[1];
    my $outputfile    = $_[0];
    my $thisValueStr;
    my $expectedValueStr;

    # use hex if valueType is a firmware version
    if ($valueType =~ /firmware$/) {
        $thisValueStr     = sprintf("%X", $thisValue);
        $expectedValueStr = sprintf("%X", $expectedValue);
    }
    else {
        $thisValueStr     = $thisValue;
        $expectedValueStr = $expectedValue;
    }
    if ($thisValue >= $expectedValue) {
        msgPrint($outputfile, "S", "",
                "Sufficient $valueType (>=$expectedValueStr): $thisValueStr");
        return SUCCESS;
    }
    elsif ($_[4] == FAILURE) {
        msgPrint($outputfile, "E", "",
                 "Insufficient $valueType : $thisValueStr");
        msgPrint($outputfile, "I", "",
                 "Minimum $valueType : $expectedValueStr");
        return FAILURE;
    }
    else {
        msgPrint($outputfile, "W", "",
                 "Insufficient $valueType : $thisValueStr");
        msgPrint($outputfile, "I", "",
                 "Minimum $valueType : $expectedValueStr");
        return WARNING;
    }
}

sub checkMinAlphanumValue {
    my $outputfile    = $_[0];
    my $valueType     = $_[1];
    my $thisValue     = $_[2];
    my $expectedValue = $_[3];
    my $result        = 1;
    my $done          = 0;
    my $i;
    my $thisChar;
    my $expectedChar;

    #first char must be equal
    if (substr ($thisValue, 0, 1) eq substr ($expectedValue, 0, 1)) {
        for ($i = 1; ($i < length ($expectedValue)) && ($done == 0); $i ++ ) {
            $thisChar     = substr ($thisValue, $i, 1);
            $expectedChar = substr ($expectedValue, $i, 1);

            if ($thisChar =~ /[0-9]/) {
                if ($expectedChar =~ /[0-9]/) {
                    # both chars are numbers
                    if ($thisChar != $expectedChar) {
                        $done = 1;
                        if ($thisChar < $expectedChar) {
                            #thisValue is older than expected.
                            $result = 0;
                        }
                        #else thisValue is newer than expected.
                    }
                }
                else {
                    #expectedChar in [A-Z] and is larger.
                    $result = 0;
                    $done = 1;
                }
            }
        else {
            #$thisChar =~ [A-Z]
            if ($expectedChar =~ /[A-Z]/) {
                # both chars are upper case letters
                if ($thisChar ne $expectedChar) {
                    $done = 1;
                    if ($thisChar lt $expectedChar) {
                        #thisValue is older than expected.
                        $result = 0;
                    }
                    #else thisValue is newer than expected.
                }
            }
            else {
                #expectedChar is a number and is smaller.
                $done = 1;
                }
            }
        }
    }
    else {
        $result = 0;
    }

    if ($result == 1) {
        msgPrint($outputfile, "S", "",
                "Sufficient $valueType (>=$expectedValue): $thisValue");
        return SUCCESS;
     }
     elsif ($_[4] == FAILURE) {
        msgPrint($outputfile, "E", "",
                 "Insufficient $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Minimum $valueType : $expectedValue");
        return FAILURE;
     }
     else {
        msgPrint($outputfile, "W", "",
                 "Insufficient $valueType : $thisValue");
        msgPrint($outputfile, "I", "",
                 "Minimum $valueType : $expectedValue");
        return WARNING;
     }
}

sub checkMaxValue {
    my $thisValue     = $_[2];
    my $expectedValue = $_[3];
    my $valueType     = $_[1];
    my $outputfile    = $_[0];
    my $thisValueStr;
    my $expectedValueStr;

    # use hex if valueType is a firmware version
    if ($valueType =~ /firmware$/) {
        $thisValueStr     = sprintf("%X", $thisValue);
        $expectedValueStr = sprintf("%X", $expectedValue);
    }
    else {
        $thisValueStr     = $thisValue;
        $expectedValueStr = $expectedValue;
    }
    if ($thisValue <= $expectedValue) {
        msgPrint($outputfile, "S", "",
                "Sufficient $valueType (<=$expectedValueStr): $thisValueStr");
        return SUCCESS;
    }
    elsif ($_[4] == FAILURE) {
        msgPrint($outputfile, "E", "",
                 "Greater $valueType : $thisValueStr");
        msgPrint($outputfile, "I", "",
                 "Maximum $valueType : $expectedValueStr");
        return FAILURE;
    }
    else {
        msgPrint($outputfile, "W", "",
                 "Greater $valueType : $thisValueStr");
        msgPrint($outputfile, "I", "",
                 "Maximum $valueType : $expectedValueStr");
        return WARNING;
    }
}

#msgPrint - Print the passed message in color coded manner
#arg1 - file descriptor to print to
#arg2 - type of message - INFO(I),ERROR(E),WARNING(W),RESULT(R),VERBOSE(V),SUCESS(S)
#arg3 - functionname printing this info
#arg4 - message to be printed
sub msgPrint {
    my $output = shift;
    my ($msgtype, $funcname, $msg) = @_;
    if (ref($output) eq 'ARRAY') {
        my $outfile;
        foreach $outfile (@$output) {
            msgPrint($outfile, $msgtype, $funcname, $msg);
        }
        return;
    }
    local (*FD) = $output;

    if ($colorScheme && -t $output) {

        #print the colored prefix based on the type of message
        if ($msgtype eq "I") {
            print FD BOLD, BLUE, "INFO:", RESET;
        }
        if ($msgtype eq "E") {
            print FD BOLD, RED, "ERROR:", RESET;
        }
        if ($msgtype eq "W") {
            print FD BOLD, MAGENTA, "WARNING:", RESET;
        }
        if ($msgtype eq "S") {
            print FD BOLD, GREEN, "SUCCESS:", RESET;
        }
        if ($msgtype eq "R") {
            print FD BOLD, YELLOW, "RESULT:", RESET;
        }
        if ($msgtype eq "V") {
            print FD BOLD, CYAN, "DEBUG:", RESET, "  $funcname:";
        }
    }
    else {

        #print the non-colored prefix based on the type of message
        if ($msgtype eq "I") {
            print FD "INFO:";
        }
        if ($msgtype eq "E") {
            print FD "ERROR:";
        }
        if ($msgtype eq "W") {
            print FD "WARNING:";
        }
        if ($msgtype eq "S") {
            print FD "SUCCESS:";
        }
        if ($msgtype eq "R") {
            print FD "RESULT:";
        }
        if ($msgtype eq "V") {
            print FD "DEBUG:", "  $funcname:";
        }
    }

    #print the actual message
    print FD " $msg\n";
}

sub printDataStruct {
    local (*FD) = shift;
    my ($refds) = @_;

    print FD Dumper($refds);
}

sub turnoffColorscheme {
    $colorScheme = 0;
}

sub turnonColorscheme {
    $colorScheme = 1;
}

#trim - remove extra spaces in the begining and end of string and return it back.
sub trim {
    my ($string) = @_;
    if (defined $string && length($string) > 0) {
        $string =~ s/^\s+|\s+$//g;
    }
    return $string;
}


sub DoExecCmd {
    my ($cmd, $cmdinput, $redirect_stderr) = @_;
    my $parent_write_hdl = \*TOCMD;
    my $parent_read_hdl  = \*FROMCMD;
    my $child_write_hdl;
    my $child_read_hdl;
    my $cmdoutput = "";
    my $rc;
    my @retval;
    pipe $child_read_hdl,  $parent_write_hdl or die;
    pipe $parent_read_hdl, $child_write_hdl  or die;

    if (!defined($redirect_stderr)) {
        $redirect_stderr = 1;
    }

    my $pid = fork();
    die "fork() failed: $!" unless defined $pid;

    if ($pid) {
        close $child_read_hdl;
        close $child_write_hdl;
        if (defined($cmdinput) && ($cmdinput ne "")) {
            print TOCMD "$cmdinput";
        }
        close TOCMD;

        while (<FROMCMD>) {
            $cmdoutput = $cmdoutput . $_;
        }

        close FROMCMD;

        waitpid($pid, 0);

        $rc = "$?";
        @retval = ($rc, $cmdoutput);
    }
    else {
        close $parent_read_hdl;
        close $parent_write_hdl;
        open(STDIN,  "<&=" . fileno($child_read_hdl))  or die;
        open(STDOUT, ">&=" . fileno($child_write_hdl)) or die;
        if ($redirect_stderr) {
            open(STDERR, ">&STDOUT") or die;
        }
        exec $cmd;
    }

    return @retval;
}

sub includeJsonConfig {
    my %config;
    my @node_lists = (
                      "NODE_NAMES", "NODE_IPS", "ADM_NAMES",  "ADM_IPS",
                      "PRIV_NAMES", "PRIV_IPS", "ILOM_NAMES", "ILOM_IPS"
    );
    my @generic_objects = ("BDDCS_SERVICE");
    my $jscmd = "$JSON_SELECT --jpx=\\?m - ";
    my @retval;
    my $rc;
    my $file_json      = "/opt/oracle/bda/install/state/config.json";
    my $param_list_str = "";
    my @param_list;
    my $rack_param_list_str = "";
    my @rack_param_list;
    my $idx;
    my $idx2;
    my $idx3;
    my $param_name;
    my $param_value;
    my @param_value_arr;
    my $param_type;
    my @rack_name;
    my $numelem;
    my $rack_param_name;
    my $tmpval;
    my @rack_param_value;

    open my $fh, '<', "$file_json" or die "Can't open file $!";
    my $file_text = do {local $/; <$fh>};
    close($fh);

    @retval = DoExecCmd($jscmd, $file_text);
    $rc = shift @retval;
    if ($rc != 0) {
        die "Error parsing $file_json";
    }

    $param_list_str = shift @retval;
    $param_list_str = trim($param_list_str);
    @param_list     = split(/\s+/, $param_list_str);

    for ($idx = 0; $idx <= $#param_list; $idx++) {
        $param_name = $param_list[$idx];
        if ($param_name ne "RACKS") {
            $jscmd = "$JSON_SELECT --jpx=${param_name} - ";

            @retval = DoExecCmd($jscmd, $file_text);

            $rc = shift @retval;

            if ($rc != 0) {
                die "Error parsing $file_json";
            }

            $param_value = shift @retval;
            $param_value = trim($param_value);
            $param_value =~ s/^false$/0/;
            $param_value =~ s/^true$/1/;

            $jscmd = "$JSON_SELECT --jpx=${param_name}\\?t - ";
            @retval = DoExecCmd($jscmd, $file_text);

            $rc = shift @retval;

            if ($rc != 0) {
                die "Error parsing $file_json";
            }

            $param_type = shift @retval;
            $param_type = trim($param_type);
            if ($param_type eq "object") {
                if(grep {/^$param_name$/} @generic_objects){
                  # store full json object as is
                  $config{lc($param_name)} = $param_value;
                } else {
                  # if it is an unrecognized object, error out
                  die "Unexpected parameter in $file_json";
                }
            }
            elsif ($param_type eq "array") {
                @param_value_arr = split(/\s+/, $param_value);
                my $tmparr = ();
                push(@{$tmparr}, @param_value_arr);
                $config{lc($param_name)} = $tmparr;
            }
            else {
                $config{lc($param_name)} = $param_value;
            }
        }
        else {
            $jscmd  = "$JSON_SELECT --jpx=${param_name}\\?n - ";
            @retval = DoExecCmd($jscmd, $file_text);
            $rc     = shift @retval;
            if ($rc != 0) {
                die "Error parsing $file_json";
            }

            $numelem = shift @retval;
            if ($numelem < 1) {
                die "No rack information found in $file_json";
            }

            $jscmd  = "$JSON_SELECT --jpx=${param_name}[1]\\?m - ";
            @retval = DoExecCmd($jscmd, $file_text);
            $rc     = shift @retval;
            if ($rc != 0) {
                die "Error parsing $file_json";
            }

            $rack_param_list_str = shift @retval;
            $rack_param_list_str = trim($rack_param_list_str);
            @rack_param_list     = split(/\s+/, $rack_param_list_str);

            for ($idx2 = 0; $idx2 <= $#rack_param_list; $idx2++) {
                $rack_param_name = $rack_param_list[$idx2];

                $jscmd
                  = "$JSON_SELECT --jpx=${param_name}/${rack_param_name} - ";
                @retval = DoExecCmd($jscmd, $file_text);

                $rc = shift @retval;

                if ($rc != 0) {
                    die "Error parsing $file_json";
                }

                $tmpval = shift @retval;

                @rack_param_value = split(/\s+/, trim($tmpval));

                my $tmparr = ();
                push(@{$tmparr}, @rack_param_value);
                $config{lc($rack_param_name)} = $tmparr;

                if ($rack_param_name eq "NODE_NAMES") {
                    $config{"num_servers"} = $#rack_param_value + 1;
                }
            }
        }
    }

    # Make sure name servers and ntp servers are also added to config
    for $param_name (("NAME_SERVERS", "NTP_SERVERS")) {

        #$jscmd = "$JSON_SELECT --jpx=${param_name} --deploy ";
        my $bdacliParam = "rack_" . lc $param_name;
        $jscmd = "/opt/oracle/bda/bin/bdacli getinfo $bdacliParam";
        @retval = DoExecCmd($jscmd, "");

        $rc = shift @retval;

        if ($rc != 0) {
            die "Error running 'bdacli getinfo RACK_${param_name}'";
        }

        $param_value = shift @retval;
        @param_value_arr = split(/\s+/, trim($param_value));
        my $tmparr = ();
        push(@{$tmparr}, @param_value_arr);
        $config{lc($param_name)} = $tmparr;
    }

    return %config;
}

# include config parameters. By default use
# /opt/oracle/bda/install/state/config.json
sub includeConfig {
    my $file = $_[0];
    my $file_json;
    my %config;

    if ($#_ == -1) {
        $file = "/opt/oracle/bda/install/state/config.json";
    }

    if (-f $file && $file eq "/opt/oracle/bda/install/state/config.json") {
        $file_json = "/opt/oracle/bda/install/state/config.json";
        %config    = includeJsonConfig();
        return %config;
    }
    $file = "/opt/oracle/bda/install/state/mammoth-saved.params";

    open(FILE, $file)
      || ($config{"error"} = "Cluster not fully deployed yet.",
          return %config);
    while (<FILE>) {
        next if (/^(#.*|\s*)$/);
        my ($key, $val) = split(/\s*=\s*/, $_, 2);

        # parsing code for bdaconfig.params
        $val =~ s/@/\\@/;
        $val =~ s/^\s*(.*?)\s*$/$1/;   # strip leading and trailing whitespace
        $val =~ s/^false$/0/;
        $val =~ s/^true$/1/;
        if ($val =~ /^\(/) {

            # $val is an array
            $val =~ s/^\((.*?)\)$/$1/;    # strip start and end braces
            my @val = split(/\s+/, $val);
            $config{lc($key)} = \@val;

            # print("key ".lc($key)." is array - @val.\n");
        }
        else {

            # $val is a scalar
            $config{lc($key)} = $val;

            # print("key ".lc($key)." has value $val.\n");
        }

        # parsing code for environment.pp
        # $val =~ s/@/\\@/;
        # $val =~ s/^ *false *$/0/;
        # $val =~ s/^ *true *$/1/;
        # $val =~ s/, *]/ ]/;
        # $key =~ s/^\$//;
        # $config{$key} = eval($val);

        $config{"error"} = "Error on line $.:\n$@\n" if ($@);
    }
    close(FILE);
    return %config;
}

sub encodeBase64 {
    my ($output_str) = @_;

    chomp($output_str);
    my $encoded_output_str = encode_base64($output_str, "");
    chomp($encoded_output_str);
    return $encoded_output_str;
}

sub getOutputStrFromFile {
    my ($file_path, $max_output_size, $output_head) = @_;

    my $output_str = "";
    if (($max_output_size == 0) || (! -f $file_path)){
        return encodeBase64($output_str);
    }

    my $file_size = -s $file_path;
    if ($file_size < $max_output_size){
        $output_str = `cat $file_path`;
        return encodeBase64($output_str);
    }

    my $file_contents;
    open(FILE, "<", $file_path) || return "";
    if ($output_head) {
        ;
    }
    else {
        seek(FILE, 0, 2);
        seek(FILE, (0 - $max_output_size), 1);
    }

    while (read(FILE, $file_contents, $max_output_size)) {
        $output_str = $file_contents;
        last;
    }

    close(FILE);

    return encodeBase64($output_str);
}


=head2 execCmdWithTimeout

 Access level: Public
 Parameters  : Timeout (string), Command (string)
 Returns     : Output of command (string) / None (if timed out)
 Description : Executes command with timeout
 Usage       : $output = execCmdWithTimeout("2","sleep 3; echo foo");

=cut

sub execCmdWithTimeout {
    my $timeout     = shift;
    my $command     = shift;
    my $output_file = "/tmp/timeout_output";

    my $pid = fork();
    defined $pid or die "fork: $!";
    $pid == 0 && exec("$command > $output_file");

    my $timed_out = 0;
    $SIG{ALRM} = sub {$timed_out = 1; die;};
    alarm $timeout;
    eval {waitpid $pid, 0};
    alarm 0;
    if ($timed_out) {
        print "Timed out!\n";
        kill 9, $pid;
        return;
    }

    return `cat $output_file`;
}


=head2 getCallStack

 Access level: Public
 Parameters  : None
 Returns     : Call Stack (String)
 Description : Returns the name of the function where getCallStack is called
 Usage       : $call_stack = getCallStack()

=cut

sub getCallStack {
    my @call_stack_arr = ();
    for (my $i = 1; $i <= 4; $i += 1) {
        my $val = (caller($i))[3];
        if (defined $val) {
            push @call_stack_arr, $val;
        }
        else {
            last;
        }
    }

    my $call_stack;
    while (@call_stack_arr) {
        my $val = pop @call_stack_arr;
        my @val_arr = split(/::/, $val);
        $call_stack = $call_stack . $val_arr[-1];
        if (@call_stack_arr) {
            $call_stack = $call_stack . "->";
        }
    }

    return $call_stack;
}

sub _getLoggingTime {
    my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)
      = localtime(time);
    my $nice_timestamp = sprintf("%04d%02d%02d %02d:%02d:%02d",
                                 $year + 1900,
                                 $mon + 1, $mday, $hour, $min, $sec);
    return $nice_timestamp;
}

=head2 writeToLog

 Access level: Public
 Parameters  : Log file name (String), Call Stack (String), Log message (String)
 Returns     : None
 Description : Appends Datestamp (String), Call Stack (String), Log message (String) to Log file
 Usage       : writeToLog($log_file, $call_stack, $log_message)

=cut

sub writeToLog {
    my ($log_file, $call_stack, $log_message) = @_;

    my $log_file_size = 0;

    my $log_file_path = "/var/log/" . $log_file;

    # Truncate if log file size is more than 100MB
    if ((-e $log_file_path)) {
      $log_file_size = int((-s $log_file_path) / (1024 * 1024)); # In MB
    }

    if ($log_file_size > 100){
        my $cmd = "tail -1000 $log_file_path > /var/log/temp; mv -f /var/log/temp $log_file_path";
        system($cmd);
    }

    my $timestamp     = _getLoggingTime();

    my $updated_log_message
      = "\n" . $timestamp . " : " . $call_stack . " : " . $log_message;

    open(my $fh, '>>', $log_file_path)
      or die "Could not open file '$log_file_path' $!";
    print $fh $updated_log_message;
    close $fh;

    return;
}


=head2 getHostEnvironment

 ACCESS LEVEL: Public
 Parameters  : None
 Returns     : Value (String) - DOM0, DOMU, BARE, FARM
 Description : Gets host environment
 Usage       : my $host_environment = getHostEnvironment();

=cut

sub getHostEnvironment {
    my $host_environment = "BARE";

    if (!(-e $NETWORK_JSON)) {
        my $dom0_test = `virt-what | grep -ic xen-dom0`;
        if ($dom0_test =~ "1") {
          $host_environment = "DOM0";
        }
        return $host_environment;
    }

    my $bdadeploy_hostenv
      = `$JSON_SELECT --jpx="BDADEPLOY/HOSTENV" $NETWORK_JSON`;
    if ($bdadeploy_hostenv =~ "DOMU") {
        $host_environment = "DOMU";
    }
    elsif ($bdadeploy_hostenv =~ "DOM0") {
        $host_environment = "DOM0";
    }

    if (`$JSON_SELECT --jpx="BDADEPLOY/IS_VM" $NETWORK_JSON` =~ /true/) {
        $host_environment = "FARM";
    }

    return $host_environment;
}


=head2 parallelExecuteCommands

 ACCESS LEVEL: Public
 Parameters  : Command array ref
 Returns     : None
 Description : Executes command in parallel
 Usage       : parallelExecuteCommands($cmd_array_ref);

=cut
sub parallelExecuteCommands {
    my ($cmd_array_ref) = @_;

    my @threads;
    my @cmds = @{$cmd_array_ref};
    for my $cmd (@cmds) {
        push @threads, async {
            system($cmd);
        };
    }

    $_->join() for @threads;

    return;
}

sub isNotEmpty {
    my ($var) = @_;
    if (defined $var && $var ne "") {
        return 1;
    }
    return 0;
}

sub areNotEmpty {
    my (@vars) = @_;
    for my $var (@vars) {
        if (!isNotEmpty($var)) {
            return 0;
        }
    }

    return 1;
}

sub existsInSet{
    my ($element, $hash_ref) = @_;

    my %hash = %$hash_ref;
    if ($hash{$element}){
        return 1;
    }

    return 0;
}

sub isBase64 {
    my ($base64StringToTest) = @_;
    my $base64Regex = "([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?";

    return ($base64StringToTest =~ /^$base64Regex$/);
}

sub scapepwdforbash{
  my $var = \shift;
  #quotes(") and back slash(\) are the only espcecial characters
  #that needs to be treated in an special way using  the format $"" for bash(Ansi C Quoting) to be set as string not interpolated
  #$"[any string]"
  #example: var=$"'\"\\" is equal to '"\
  $$var   =~s/([\`\$\"\\])/\\$1/g;
}



sub getFormerVMNamefromJson {
  my ($vm_name) = @_;
  my $output = $vm_name;
      my $exists = `grep DOMU_MAPPING /opt/oracle/bda/cluster.json`;
      if ($exists ne "") {
          my $bdcc_setup = trim(`$JSON_SELECT --jpx='BDADEPLOY/BDCC_SETUP' /opt/oracle/bda/cluster.json`);
          if ($bdcc_setup eq "true" || $bdcc_setup eq "TRUE") {
              $output = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/DOMU_MAPPING?s(NAME:\"$vm_name\")/FORMER_NAME' /opt/oracle/bda/cluster.json`);
      }
  }
  return $output;
}

sub getVMNamefromJson {
  my ($vm_name) = @_;
  my $vmprefix = $vm_name;
  my $vmsuffix = "";
  my $output = $vm_name;

  #handle fullname mapping
  if (index ($vm_name, '.') >= 0) {
      ($vmprefix, $vmsuffix) = split(/\./, $vm_name, 2);
      $output = "$vmprefix.$vmsuffix";
  }

  my $exists = `grep DOMU_MAPPING /opt/oracle/bda/cluster.json`;
  if ($exists ne "") {
      my $bdcc_setup = trim(`$JSON_SELECT --jpx='BDADEPLOY/BDCC_SETUP' /opt/oracle/bda/cluster.json`);
      if ($bdcc_setup eq "true" || $bdcc_setup eq "TRUE") {
          $output = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/DOMU_MAPPING?s(FORMER_NAME:\"$vmprefix\")/NAME' /opt/oracle/bda/cluster.json`);
          $output = "$output.$vmsuffix";
      }

      #in case of extension
      my $existingVmNr = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/DOMU_MAPPING' --size-of /opt/oracle/bda/cluster.json`);
      my $allVmNr = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/CLIENT_NETWORK' --size-of /opt/oracle/bda/cluster.json`);
      if ($allVmNr > $existingVmNr and $output eq '.') {
        $output = $vm_name;
      }
  }
  return $output;
}


sub mapping_domuNames {

   # This is for BDCC setup only. We need to do lookup for domu names and replace
   my $output = `$JSON_SELECT --jpx='BDADEPLOY/SERVERS/CLIENT_NETWORK/NAME' /opt/oracle/bda/network.json`;
   my @temphostnames = split(" ", $output);
   my $domainName = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS[1]/CLIENT_NETWORK/DOMAIN' /opt/oracle/bda/network.json`);
   my $myHostName = trim(`hostname -s`);
   my $myNodeNr  = trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/CLIENT_NETWORK/NAME' --index-of-str=\"$myHostName\" /opt/oracle/bda/network.json`);


   my $domuMappedName =trim(`$JSON_SELECT --jpx='BDADEPLOY/SERVERS[$myNodeNr]/DOMU_MAPPING/NAME' /opt/oracle/bda/network.json`);
   print "\n domuMappedName is". $domuMappedName;
   print "\n myHostName is". $myHostName;

   if ($domuMappedName ne $myHostName) {
     # For new VM start-up or extension, not for restart VM
     for (my $idx = 0; $idx < scalar(@temphostnames); $idx++)  {
       my $temphostname = $temphostnames[$idx];
       print "\n" . $temphostname;
       my $vmIp =`$JSON_SELECT --jpx='BDADEPLOY/SERVERS/CLIENT_NETWORK?s(NAME:\"$temphostname\")/IP' /opt/oracle/bda/network.json`;
       my $iaddr = inet_aton($vmIp);
       my $vmnames = gethostbyaddr($iaddr, AF_INET);
       my $vmname = (split($domainName,$vmnames))[0];
       $vmname =~ s/\.//;

       my $cmd = "sed -i 's/$temphostname/$vmname/g' /etc/hosts";
       print "\n" . $cmd;
       system($cmd);

       $cmd = "sed -i 's/$temphostname/$vmname/g' /opt/oracle/bda/network.json";
       system($cmd);
       print "\n" . $cmd;

       my $idex = $idx+1;
       $cmd = qq($JSON_SELECT --jpx='BDADEPLOY/SERVERS[$idex]'  --insert='{"DOMU_MAPPING":{"FORMER_NAME":"$temphostname","NAME":"$vmname"}}' /opt/oracle/bda/network.json /opt/oracle/bda/network.json);
       system($cmd);
       my $log_message = "finished name mapping in domu";
       print "\n" . $log_message;
     }

     my $cmd = "/opt/oracle/bda/bin/bdanetworktool none-except vnics=true no-vnics-switches hostname=true nodenr=$myNodeNr";
     print "\n" . $cmd;
     my $out = system($cmd);
     print "\n" . $out;
   }
}


#needed in the module definition file to return true. DO not remove
1;
