#!/usr/bin/python
import glob
import os
import errno
import sys
import shutil
import time
import subprocess
import collections
from random import shuffle
from subprocess import call
import getpass
import re
import zipfile
import fnmatch
try:
    import json
except ImportError:
    import simplejson as json

hn = os.popen("hostname --fqdn")
currentnode = hn.read().strip()
#print ("check hostname: " + currentnode)
primary_cluname = ""
clucnt = 0
mammothnode = ""
scmshort = ""
scmnode = ""
setup_kts = ""
clusternodes = []
ts = int(time.time())
reportpath = ""
dumpclusterfile = ""
ismaincluster = 0
mainclucnt = 0
maincluname = ""

# src script - msg - comment
errList = []
warnList = []
infoList = []

addlList = []

# exachk outputs
failedHostChks = []
failedSwChks = []
exachk_jspath = "/tmp/scaj21bda07_exachk_results.json"
exachk_outfilespath = "/tmp/outfiles/"

cmpwd = getpass.getpass(prompt='CM admin password? ')
mysqlpwd = getpass.getpass(prompt='MySQL root password? ')


def getClusterInfo():
# calling json-select via subprocess from bdacloudcli is problematic... 
# use simplyjson module to parse segment parameters
    global clusternodes
    global scmshort
    global scmnode
    global setup_kts
    global primary_cluname
    global reportpath
    if os.path.isfile('/opt/oracle/bda/install/state/config.json'):
        reportpath = "/tmp/preupgrade_checks_" + str(ts)
        mkdir_p(reportpath)
        msgPrint("I", "All output files will be saved to path: " + reportpath)

        # standardize config.json using json-select
        cmd = "json-select --echo /opt/oracle/bda/install/state/config.json " + reportpath + "/config.json" + "; echo $?"
        r = os.popen(cmd)
        rs = r.read().rstrip()
        rs = int(rs)
        if rs != 0:
            msgPrint("EE", "Errors converting config.json to standard format")

        jspath = reportpath + "/config.json"
        jsfile = open(jspath, 'r')
        jsdata = json.load(jsfile)
        primary_cluname = str(jsdata["CLUSTER_NAME"])
        domain = str(jsdata["DOMAIN"])
        clusternodes = jsdata["DATANODE_LIST"]
        #msgPrint("I", "DATANODE_LIST: " + clusternodes)
        scmshort = str(jsdata["SCMSERVER_NODE"])
        scmnode = scmshort + "." + domain 
        #msgPrint("I", "SCM NODE: " + scmnode) 
        if "SETUP_KEY_TRUSTEE_SERVER" in jsdata:
            setup_kts = str(jsdata["SETUP_KEY_TRUSTEE_SERVER"])
        else:
            msgPrint("W", "SETUP_KEY_TRUSTEE_SERVER key not found in config.json. Assume the value is false")
            setup_kts = "false"
        #msgPrint("I", "SETUP KTS: " + setup_kts) 
    else:
        msgPrint("EE", "config.json not found")

def getFailedChecks():
    global failedHostChks
    global failedSwChks
    global exachk_jspath
    if os.path.isfile(exachk_jspath):
        msgPrint("I", "exachk summary json found.")
        jspath = exachk_jspath
        jsfile = open(jspath, 'r')

        for parsed_jsdata in load_multi_json_obj(jsfile):
            onefailedchk = []
            #failedIDs = [ (x["exachkID"] for x in parsed_jsdata if x["exachkStatus"] == "FAIL")]        
            #print ("check status:" + parsed_jsdata["exachkStatus"])
            if parsed_jsdata["exachkStatus"] == "FAIL" or parsed_jsdata["exachkStatus"] == "3":
                onefailedchk.append(str(parsed_jsdata["exachkID"]))
                onefailedchk.append(str(parsed_jsdata["exachkName"]))
                onefailedchk.append(str(parsed_jsdata["exachkAlertType"]))
                onefailedchk.append(str(parsed_jsdata["NodeName"]))
 
                if parsed_jsdata["exachkTargetType"] == "SWITCH":
                    failedSwChks.append(onefailedchk)
                elif parsed_jsdata["exachkTargetType"] == "HOST":
                    failedHostChks.append(onefailedchk)

        # sort by hostname
        failedSwChks = sorted(failedSwChks, key=lambda l:l[3])
        failedHostChks = sorted(failedHostChks, key=lambda l:l[3])
        print failedSwChks;
        print failedHostChks;
    else:
        msgPrint("E", "exachk summary json not found")

def generateFailedReport():
    reportlst = []
    if os.path.isdir(exachk_outfilespath):
        msgPrint("I", "exachk outfiles directory found.")
        # obtain failed report for switches
        if not failedSwChks:
            msgPrint("I", "No failed switch checks")
        else:
            for hidx in range(len(failedSwChks)):
                outfilename = failedSwChks[hidx][0] + "_" + failedSwChks[hidx][3] + "_report.out"
                #print ("check sw outfile name:" + outfilename)
                reportlst.append(outfilename)
        # obtain failed report for hosts
        if not failedHostChks:
            msgPrint("I", "No failed host checks")
        else:
            for hidx in range(len(failedHostChks)):
                outfilename = failedHostChks[hidx][0] + "_" + failedHostChks[hidx][3] + "_report.out"
                #print ("check host outfile name: " + outfilename)
                reportlst.append(outfilename)
    else:
        msgPrint("E", "exachk outfiles directory not found")

    print (reportlst)
    reportfilepath = "/tmp/prechecks.html.out"
    reportfile = open(reportfilepath, 'w')
    #jsfile = open(jspath, 'r')
    for fname in reportlst:
        onefilepath = exachk_outfilespath + fname
        onefile = open(onefilepath, 'r')
        for line in onefile:
            #print ("line: " + line)
            reportfile.write("<pre>" + line + "</pre> <br>\n")     
        break


def generateReport(cluname):
    htmlstr = ""
    reportfilepath = reportpath + "/" + cluname + "_prechecks.html"

    htmlstr = "<!DOCTYPE HTML PUBLIC \"http://www.w3.org/TR/html4/strict.dtd\">"
    htmlstr += "<HTML><HEAD> <STYLE type=\"text/css\">h1 {text-align: center}body {margin:0 25% 5% 5%}</STYLE>"
    htmlstr += "<title> BDA Pre-Upgrade Checks Review </title></HEAD><BODY>"
    htmlstr += "<h1>" + cluname + " Pre-Upgrade Checks Report </h1>"
    htmlstr += "<h2> Error Messages </h2>" + "<table border=\"1\">"
    htmlstr += "<tr><td>Source Script</td><td>Messages</td><td>Comments</td></tr>"
    for elem in errList:
        htmlstr += "<tr><td>" + elem[0] + "</td><td>" +  elem[1] + "</td><td>" +  elem[2] + "</td></tr>"
    htmlstr += "</table><br/><br/>";

    htmlstr += "<h2> Warning Messages </h2>" + "<table border=\"1\">"
    htmlstr += "<tr><td>Source Script</td><td>Messages</td><td>Comments</td></tr>"
    for elem in warnList:
        htmlstr += "<tr><td>" + elem[0] + "</td><td>" +  elem[1] + "</td><td>" +  elem[2] + "</td></tr>"
    htmlstr += "</table><br/><br/>";

    htmlstr += "<h2> Info Messages </h2>" + "<table border=\"1\">"
    htmlstr += "<tr><td>Source Script</td><td>Messages</td><td>Comments</td></tr>"
    for elem in infoList:
        htmlstr += "<tr><td>" + elem[0] + "</td><td>" +  elem[1] + "</td><td>" +  elem[2] + "</td></tr>"
    for elem in addlList:
        htmlstr += "<tr><td>" + elem[0] + "</td><td>" +  elem[1] + "</td><td>" +  elem[2] + "</td></tr>"
    htmlstr += "</table><br/><br/>";

    reportfile = open(reportfilepath, 'w')
    reportfile.write(htmlstr)


def runclustercheck():
    global errList
    global warnList
    global infoList

    cluchkoutput = reportpath + "/bdacheckcluster.out"
    d = dict(os.environ)
    d["CMUSR"] = "admin"
    d["CMPWD"] = cmpwd
    d["IS_INSTALL"] = "1"
    d["MYSQL_PWD"] = mysqlpwd
  
    scriptpath = os.getcwd() + "/bdacheckcluster" 
    
    #p = subprocess.Popen(['/opt/oracle/bda/bin/bdacheckcluster'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=d)
    p = subprocess.Popen([scriptpath], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=d)
    msgPrint("I", "Running bdacheckcluster...Please wait...")
    checkrs = p.communicate()[0].rstrip()
    rc = p.wait()
    msgPrint("I", "bdacheckcluster completed.")
    if rc == 0:
        msgPrint("I", "bdacheckcluster completed successfully")
    else:
        msgPrint("I", "bdacheckcluster reports errors")
    
    cluchkoutfile = open(cluchkoutput, 'w')
    cluchkoutfile.write(checkrs)
    cluchkoutfile.close()
    
    cluchkoutfile = open(cluchkoutput, 'r')
    # copying logging dir & creating report    
    for line in cluchkoutfile:
        if re.match("(.*)Logging results to(.*)", line):
            logdir = line.split('Logging results to')[1].strip()
            #print("log dir: " + logdir)
            msgPrint("I", "Saving cluster check log " + logdir + " to " + reportpath)
            rs = call(['cp', '-rf', logdir, reportpath])
            if rs != 0:
                msgPrint("EE", "Copying bdacheckcluster log dir to " + reportpath + " failed")
            
        if re.match("(.*)ERROR(.*)", line):
            onemsg = []
            onemsg.append("bdacheckcluster")
            onemsg.append(line)
            onemsg.append("Please resolve errors before upgrading cluster")
            errList.append(onemsg)
        if re.match("(.*)WARNING(.*)", line):
            onemsg = []
            onemsg.append("bdacheckcluster")
            onemsg.append(line)
            onemsg.append("Please resolve pending issues if necessary")
            warnList.append(onemsg)

    cluchkoutfile.close()
    #for err in errList:
    #    msgPrint("E", err[1])
    #for warn in warnList:
    #    msgPrint("W", warn[1])
     

def addlchecks():
    # check validity of json files
    if os.path.isfile('/opt/oracle/bda/cluster-network.json'):
        cmd = "dcli -C json-select /opt/oracle/bda/cluster-network.json"
        p = subprocess.Popen(cmd.split(), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        rc = p.wait()
        if rc != 0:
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("/opt/oracle/bda/cluster-network.json is not valid on some cluster nodes")
            onemsg.append("Please run dcli -C json-select /opt/oracle/bda/cluster-network.json to verify and resolve any issues")
            errList.append(onemsg)

    if os.path.isfile('/opt/oracle/bda/rack-network.json'):
        cmd = "dcli -C json-select /opt/oracle/bda/rack-network.json"
        p = subprocess.Popen(cmd.split(), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        rc = p.wait()
        if rc != 0:
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("/opt/oracle/bda/rack-network.json is not valid on some cluster nodes")
            onemsg.append("Please run dcli -C json-select /opt/oracle/bda/rack-network.json to verify and resolve any issues")
            errList.append(onemsg)
    else:
        cmd = "dcli -C json-select /opt/oracle/bda/network.json"
        p = subprocess.Popen(cmd.split(), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        rc = p.wait()
        if rc != 0:
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("/opt/oracle/bda/network.json is not valid on some cluster nodes")
            onemsg.append("Please run dcli -C json-select /opt/oracle/bda/network.json to verify and resolve any issues")
            errList.append(onemsg)

    # check config.json is valid
    cmd = "dcli -C json-select /opt/oracle/bda/install/state/config.json"
    p = subprocess.Popen(cmd.split(), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    rc = p.wait()
    if rc != 0:
        onemsg = []
        onemsg.append("Additional Pre-Upgrade Checks")
        onemsg.append("/opt/oracle/bda/install/state/config.json is not valid on the some cluster nodes")
        onemsg.append("Please run dcli -C json-select /opt/oracle/bda/install/state/config.json to verify and resolve any issues")
        errList.append(onemsg)

    # check config.json is the same on all nodes
    jspath_self = "/opt/oracle/bda/install/state/config.json"
    jsfile_self = open(jspath_self, 'r')
    self = json.load(jsfile_self)
    for node in clusternodes:
        configjson = "/tmp/config_" + node + ".json" 
        #cmd = "cmp -s /opt/oracle/bda/install/state/config.json <(ssh " + node + " \"cat /opt/oracle/bda/install/state/config.json\")"
        rs = call(['scp', '-p', ':'.join([node, '/opt/oracle/bda/install/state/config.json']), configjson])
        if rs != 0:
            msgPrint("EE", "Copy config.json from node " + node + " to first node failed")

        try:
            jsfile_tgt = open(configjson, 'r')
            target = json.load(jsfile_tgt) 
            if sorted(self.items()) != sorted(target.items()):
                #msgPrint("E", "config.json on node " + node + " is different from the config.json on the first node")
                onemsg = []
                onemsg.append("Additional Pre-Upgrade Checks")
                onemsg.append("config.json on node " + node + " is different from the config.json on the first node")
                onemsg.append("Please make sure /opt/oracle/bda/install/state/config.json is identical on each cluster node")
                errList.append(onemsg)

        except ValueError:
            #msgPrint("E", "config.json from node " + node + " is unable to load")
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("config.json on node " + node + " is unable to load")
            onemsg.append("Please make sure /opt/oracle/bda/install/state/config.json is in valid json format")
            errList.append(onemsg)


    #check service restart of cloudera-scm-server on all nodes except the scm node
    if os.path.isfile('/opt/oracle/bda/cluster-network.json'):
        cmd = "json-select --jpx=BDADEPLOY/SERVERS/CLIENT_NETWORKS[1]/NAME --index-of-str=" + scmshort + " /opt/oracle/bda/cluster-network.json"
    else:
        cmd = "json-select --jpx=BDADEPLOY/SERVERS/CLIENT_NETWORK/NAME --index-of-str=" + scmshort + " /opt/oracle/bda/network.json"
    idx = os.popen(cmd)
    scmidx = idx.read().strip()
    idx1 = int(scmidx) - 1
    idx2 = int(scmidx) + 1

    cmd = "json-select --jpx=\"racks/priv_ips[:" + str(idx1) + "," + str(idx2) + ":]\" /opt/oracle/bda/install/state/config.json | tr ' ' ','"
    r = os.popen(cmd)
    nodelst = r.read().strip()

    #cmd = "dcli -c " + nodelst + " service cloudera-scm-server restart"
    cmd = "dcli -c " + nodelst + " service cloudera-scm-server restart"
    p = subprocess.Popen(cmd.split(), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    rc = p.wait()
    if rc != 0:
        onemsg = []
        onemsg.append("Additional Pre-Upgrade Checks")
        onemsg.append("Error restating cloudera-scm-server service on some nodes")
        onemsg.append("Upgrade to BDA versions earlier than 4.12 may fail. Please resolve issues before upgrade")
        errList.append(onemsg)

    # check existence of create truststore scripts if TLS is enabled. Renew certs will fail if scripts are not in place
    cmd = "cat /etc/cloudera-scm-agent/config.ini  | grep  '^\s*use_tls' | awk -F'=' '{print $2}'"
    r = os.popen(cmd)
    rs = r.read().rstrip()
    rs = int(rs)
    if rs == 1:
        msgPrint("I", "TLS level 2 is enabled. Checking existence of truststore creation scripts")
        create1found = 0
        create2found = 0
        if os.path.isdir('/opt/cloudera/security/jks'):
            for file in os.listdir('/opt/cloudera/security/jks'):
                if fnmatch.fnmatch(file, 'create*pl'):
                    create1found = 1
                    msgPrint("I", file + " is in place")
            if create1found == 0:
                onemsg = []
                onemsg.append("Additional Pre-Upgrade Checks")
                onemsg.append("create truststore script not found at /opt/cloudera/security/jks")
                onemsg.append("Please restore this script on the first node from the other cluster nodes")
                errList.append(onemsg)
        else:
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("TLS level2 is enabled however dir /opt/cloudera/security/jks is not found")
            onemsg.append("Please resolve issues before upgrade")
            errList.append(onemsg)
    
        if os.path.isdir('/opt/cloudera/security/x509'):
            for file in os.listdir('/opt/cloudera/security/x509'):
                if fnmatch.fnmatch(file, 'create_hue*pl'):
                    create2found = 1
                    msgPrint("I", file + " is in place")
            if create2found == 0:
                onemsg = []
                onemsg.append("Additional Pre-Upgrade Checks")
                onemsg.append("create_hue.truststore.pl script not found at /opt/cloudera/security/x509")
                onemsg.append("Please restore this script on the first node from the other cluster nodes")
                errList.append(onemsg)
        else:
            onemsg = []
            onemsg.append("Additional Pre-Upgrade Checks")
            onemsg.append("TLS level2 is enabled however dir /opt/cloudera/security/x509 is not found")
            onemsg.append("Please resolve issues before upgrade")
            errList.append(onemsg)
    else:
        msgPrint("I", "TLS level 2 is not enabled. Skipped related checks")


def rundumpcluster():
    global dumpclusterfile 
    dumpscriptpath = os.getcwd() + "/dumpcluster"
    dumpoutfile = "/opt/oracle/BDAMammoth/bdaconfig/tmp/dumpcluster.out"
    dumpclusterfile = reportpath + "/dumpcluster.out"
    #rundumpscript = dumpscriptpath + " " + clusternodes[0] + " " + backupdest + " " + str(d)
    rs = call([dumpscriptpath, '-h', scmnode, '-p', cmpwd])
    if rs != 0:
        msgPrint("EE", "Running dumpcluster script on node " + currentnode + " failed")
    if os.stat(dumpoutfile).st_size == 0:
        msgPrint("EE", "No content in dumpcluster.out. Please resolve issues running dumpcluster tool")
    rs = call(['cp', '-f', dumpoutfile, reportpath])
    if rs != 0:
        msgPrint("EE", "Copying dumpcluster.out to " + reportpath + " failed")


def parsedumpcluster(cluidx): 
    activeparcels = []
    datanodelist = []
    allnodelist = []
    allnodemap = []
    edgenodelist = []
    servlist = []
    global errList
    global warnList
    global infoList
    global ismaincluster
    global mainclucnt
    global addlList
    allhostcnt = 0
    bdahostcnt = 0
    ismaincluster = 0
    authval = ""
    kdctype = ""


    if os.path.isfile(dumpclusterfile):
        jspath = dumpclusterfile
        jsfile = open(jspath, 'r')
        jsdata = json.load(jsfile)
        
        cluname = jsdata["clusters"][cluidx]["displayName"]

        # getting parcel info
        for parcel in jsdata["clusters"][cluidx]["parcels"]:
            oneactiveparcel = []
            if str(parcel["stage"]) == "ACTIVATED":
                oneactiveparcel.append(str(parcel["product"]))
                oneactiveparcel.append(str(parcel["version"]))
                activeparcels.append(oneactiveparcel)

        for serv in jsdata["clusters"][cluidx]["services"]:
            # getting services info
            servlist.append(str(serv["type"]))
            if serv["type"] == "HDFS":
                # getting datanode info
                for role in serv["roles"]:
                    if role["type"] == "DATANODE":
                        datanodelist.append(str(role["hostRef"]["hostId"]))
                    # checking if this is main cluster
                    if role["type"] == "NAMENODE":
                        ismaincluster = 1
             
                # getting security info
                for item in serv["config"]["items"]:
                    if item["name"] == "hadoop_security_authentication":
                        authval = item["value"]
        
        if ismaincluster == 0:
            onemsg = []
            #if set(servlist) == {['KEYTRUSTEE_SERVER']}:
            if len(set(servlist)) == 1 and 'KEYTRUSTEE_SERVER' in servlist:
                onemsg.append("dumpcluster")
                onemsg.append("Cluster " + cluname + " found. It is dedicated to setting up Keytrustee Server and not managed by mammoth")    
            else: 
                onemsg.append("dumpcluster")
                onemsg.append("Cluster " + cluname + " found. It is not managed by mammoth")
            onemsg.append("Nodes managed by this cluster might be treated as edge nodes of the Main cluster")
            addlList.append(onemsg)
            return
        else:
            mainclucnt += 1        
  
        for mgmtitem in jsdata["managerSettings"]["items"]:
            if mgmtitem["name"] == "KDC_TYPE":
                kdctype = mgmtitem["value"]


        # getting hosts info
        for host in jsdata["hosts"]:
            allhostcnt += 1
            onenodemap = []
            allnodelist.append(str(host["hostId"]))
            onenodemap.append(str(host["hostId"]))
            onenodemap.append(str(host["hostname"]))
            onenodemap.append(str(host["ipAddress"]))
            allnodemap.append(onenodemap)

    else:
        msgPrint("EE", "dumpcluster.out not found")

#    print("all activate parcels " + str(activeparcels)) 
#    print("datanode list " + str(datanodelist)) 
#    print("all node list " + str(allnodelist)) 
#    print("all node map " + str(allnodemap)) 
#    print("service list " + str(servlist)) 
#    print("all host count " + str(allhostcnt))
#    print("check security " + authval)
#    print("kdc type " + kdctype) 

    # check security features
    onemsg = []
    onemsg.append("dumpcluster")
    if authval == "kerberos":
        onemsg.append("Kerberos is enabled. KDC type is " + kdctype)
    else:
        onemsg.append("Kerberos is not enabled")
    onemsg.append("")
    infoList.append(onemsg)
       

    # check parcels
    for pidx in range(len(activeparcels)):
        onemsg = []
        onemsg.append("dumpcluster")
        onemsg.append(activeparcels[pidx][0] + " Parcel " + activeparcels[pidx][1] + " is activated")
        if activeparcels[pidx][0] == "CDH":
            onemsg.append("")
            infoList.append(onemsg)
        #KMS - info
        elif activeparcels[pidx][0] == "KEYTRUSTEE":
            onemsg.append("")
            infoList.append(onemsg)
        #BIGDATASQL - info
        elif activeparcels[pidx][0] == "BIGDATASQL":
            onemsg.append("")
            infoList.append(onemsg)
        #SPARK2 - info
        elif activeparcels[pidx][0] == "SPARK2":
            onemsg.append("")
            infoList.append(onemsg)
        #KTS - warn
        elif activeparcels[pidx][0] == "KEYTRUSTEE_SERVER":
            if setup_kts == "false":
                onemsg.append("SETUP_KEY_TRUSTEE_SERVER is set to false in config.json so Mammoth won't take care of updating keytrustee server during upgrade")
                warnList.append(onemsg)
        elif activeparcels[pidx][0] == "KAFKA":
            onemsg.append("KAFKA parcel won't be updated by mammoth automatically during upgrade. Customer need to upgrade KAFKA manually")
            warnList.append(onemsg)
        else:
            onemsg.append(activeparcels[pidx][0] + " parcel is not managed by mammoth so customer needs to take care of updating them")
            warnList.append(onemsg)

    # check hosts
    datanodelist.sort()
    allnodelist.sort()
#    print("sorted datanode list " + str(datanodelist))
#    print("sorted all node list " + str(allnodelist))

    if len(allnodelist) > len(set(allnodelist)):
        onemsg = []
        onemsg.append("dumpcluster")
        onemsg.append("Duplicate hosts found in this cluster")
        onemsg.append("Please resolve errors before upgrading cluster")
        errList.append(onemsg)

    if set(allnodelist) == set(datanodelist): 
        onemsg = []
        onemsg.append("dumpcluster")
        onemsg.append("There is no edge node in this cluster")
        onemsg.append("")
        infoList.append(onemsg)
    else:            
        edgenodelist = [x for x in allnodelist if x not in datanodelist]

    bdahostcnt = allhostcnt - len(edgenodelist)
#    print("bda host count " + str(bdahostcnt))
    onemsg = []
    onemsg.append("dumpcluster")
    onemsg.append("This cluster has " + str(bdahostcnt) + " BDA nodes")
    onemsg.append("")
    infoList.append(onemsg)

    if len(edgenodelist) > 0:
        for nodeid in edgenodelist:
            nodename = ""
            for nodemap in allnodemap:
                if nodeid == nodemap[0]:
                    nodename = nodemap[1]
                    onemsg = []
                    onemsg.append("dumpcluster")
                    onemsg.append("This cluster has edge node " + nodemap[1])
                    onemsg.append("Customer need to follow specific instructions to upgrade the CM agent on edge node before upgrade. If there is no critical services/roles configured on edge node, customer can also consider to remove edge node from cluster.")
                    warnList.append(onemsg)
                   
            # check roles on edge nodes
            edgeservs = []
            impt_edgeservs = []
            for serv in jsdata["clusters"][cluidx]["services"]:
                for role in serv["roles"]:
                    if str(role["hostRef"]["hostId"]) == nodeid:
                        edgeservs.append(str(role["name"]))
           
            onemsg = []
            onemsg.append("dumpcluster")
            for edgerole in edgeservs:
                if "GATEWAY" not in edgerole:
                    impt_edgeservs.append(edgerole)
            if not impt_edgeservs: 
                onemsg.append("Hadoop Roles configured on edge node " + nodename + " are: " + str(edgeservs)) 
                onemsg.append("No critical roles found on this edge node.")
                infoList.append(onemsg)
            else:
                onemsg.append("Critical Hadoop Roles configured on edge node " + nodename + " are: " + str(impt_edgeservs))     
                onemsg.append("Please be cautious to remove this edge node from cluster.")
                warnList.append(onemsg)
 
    # check services
    onemsg = []
    onemsg.append("dumpcluster")
    onemsg.append("Services configured on this cluster: " + str(servlist))
    onemsg.append("")
    infoList.append(onemsg)

    # check roles on edge nodes
    edgeservlist = []
    for serv in jsdata["clusters"][cluidx]["services"]:
        for role in serv["roles"]:
            if str(role["hostRef"]["hostId"]) in edgenodelist:
                oneedgeserv = []
                oneedgeserv.append(str(role["hostRef"]["hostId"]))
                oneedgeserv.append(str(role["name"]))
                edgeservlist.append(oneedgeserv)
             
    #print("edge node services list " + str(edgeservlist))
    #print("err list " + str(errList))
    #print("warn list " + str(warnList))
    #print("info list " + str(infoList))
    for err in errList:
        msgPrint("E", err[1])
    for warn in warnList:
        msgPrint("W", warn[1])



def compareList(x, y):
    compare = lambda x, y: collections.Counter(x) == collections.Counter(y)
    print("test comapre: " + str(compare))
    return compare    

def load_multi_json_obj(jsf):
    chunk = ""
    for seg in jsf:
        chunk += seg
        try:
            yield json.loads(chunk)
            chunk = ""
        except ValueError:
            pass

def mkdir_p(path):
    try:
        os.makedirs(path)
    except os.error, e:
        if e.errno != errno.EEXIST:
            raise

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))

def msgPrint(type, msg):
    if type == "I":
        print ("INFO: " + msg)
    elif type == "S":
        print ("SUCCESS: " + msg)
    elif type == "W":
        print ("WARNING: " + msg)
    elif type == "E":
        print ("ERROR: " + msg)
    elif type == "EE":
        print ("ERROR: " + msg)
        errExit()

def errExit():
    print ("ERROR: Clean output directory and Exiting...")
    rs = call(['rm', '-rf', reportpath])
    if rs != 0:
        msgPrint("E", "Failed removing output directory " + reportpath)
    sys.exit(1)


if __name__ == "__main__":
    getClusterInfo()
    runclustercheck()  
    addlchecks()
    rundumpcluster()
    if os.path.isfile(dumpclusterfile):
        jspath = dumpclusterfile
        jsfile = open(jspath, 'r')
        jsdata = json.load(jsfile)
        # check num of clusters
        clucnt = len(jsdata["clusters"])
        if clucnt < 1:
            msgPrint("EE", "No cluster found in Cloudera Manager")
        elif clucnt >= 1:
            msgPrint("I", str(clucnt) + " clusters found in Cloudera Manager")
            for cidx in range(clucnt):
                parsedumpcluster(cidx)
                if ismaincluster != 0:
                    maincluname = jsdata["clusters"][cidx]["displayName"]
            msgPrint("I", str(mainclucnt) + " main cluster found")
            if mainclucnt == 0:
                msgPrint("EE", "No main hadoop cluster detected in Cloudera Manager") 
            elif mainclucnt > 1:
                msgPrint("EE", "More than one main cluster detected in Cloudera Manager. BDA does not support this configuration")
            else:
                generateReport(maincluname)
    else:
        msgPrint("EE", "No dumpcluster.out found")

    # compress report dir
    #zipname = os.path.basename(reportpath) + ".zip"
    zipname = reportpath + ".zip"
    zipf = zipfile.ZipFile(zipname, 'w', zipfile.ZIP_DEFLATED)
    zipdir(reportpath, zipf)
    zipf.close()
    msgPrint("I", "Zip bundle created at " + zipname)
 
    sys.exit(0)
    #getFailedChecks()
    #generateFailedReport()
